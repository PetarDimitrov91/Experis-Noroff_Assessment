---Movie example---

Products.txt
------------
id, name, year, keyword 1, keyword 2, keyword 3, keyword 4, keyword 5, rating, price

Users.txt
---------
id, name, viewed (products seperated by ;), purchased (products seperated by ;)

CurrentUserSessions.txt
-----------------------
userid, productid
